
# Gümüşler Manastırı Tanıtım Sitesi

Bu proje, Niğde'deki Gümüşler Manastırı'nı tanıtmak amacıyla hazırlanmıştır.

## İçerikler
- Manastır hakkında bilgi
- Etkinlikler listesi
- Gerçek fotoğraflar
- İletişim bölümü

## Canlı Önizleme
Bu projeyi GitHub Pages kullanarak kolayca yayınlayabilirsiniz.
